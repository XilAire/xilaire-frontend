import type {
  Metadata,
} from "next";

import {
  redirect,
} from "next/navigation";

import RegisterForm from "@/components/auth/RegisterForm";

import {
  normalizePaidPlanKey,
  normalizeSourceProduct,
} from "@/lib/auth/registration-intent";

import {
  createSupabaseServerClient,
} from "@/lib/supabase/server";

export const metadata: Metadata = {
  title:
    "Create Account | CASE University",

  description:
    "Create your CASE University account and continue with your selected membership.",
};

export const dynamic =
  "force-dynamic";

type RegisterPageSearchParams = {
  plan?:
    | string
    | string[];

  source?:
    | string
    | string[];
};

type RegisterPageProps = {
  searchParams:
    | Promise<RegisterPageSearchParams>
    | RegisterPageSearchParams;
};

function firstValue(
  value:
    | string
    | string[]
    | undefined,
): string | undefined {
  return Array.isArray(
    value,
  )
    ? value[0]
    : value;
}

export default async function RegisterPage({
  searchParams,
}: RegisterPageProps) {
  const resolved =
    await Promise.resolve(
      searchParams,
    );

  const planKey =
    normalizePaidPlanKey(
      firstValue(
        resolved.plan,
      ),
    );

  const sourceProduct =
    normalizeSourceProduct(
      firstValue(
        resolved.source,
      ),
    );

  const supabase =
    await createSupabaseServerClient();

  const {
    data: {
      user,
    },
  } =
    await supabase.auth.getUser();

  if (user) {
    if (planKey) {
      redirect(
        `/pricing?checkout_plan=${encodeURIComponent(
          planKey,
        )}`,
      );
    }

    redirect(
      "/dashboard",
    );
  }

  return (
    <main className="min-h-screen bg-[var(--surface-muted)] px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto grid w-full max-w-6xl overflow-hidden rounded-3xl border border-[var(--border-subtle)] bg-[var(--surface-default)] shadow-[var(--shadow-md)] lg:grid-cols-[0.9fr_1.1fr]">
        <section className="bg-[var(--primary)] p-8 text-[var(--primary-foreground)] sm:p-10 lg:p-12">
          <p className="text-xs font-extrabold uppercase tracking-[0.2em] opacity-80">
            CASE University
          </p>

          <h1 className="mt-5 max-w-xl text-4xl font-black tracking-tight sm:text-5xl">
            Build your investing knowledge with a structured learning path.
          </h1>

          <p className="mt-5 max-w-lg text-base leading-7 opacity-90">
            Create one account to access your CASE University learning dashboard, progress, practice, resources, and eligible certificates.
          </p>

          <div className="mt-10 space-y-4 text-sm font-semibold leading-6">
            <p>
              ✓ Your selected plan is preserved through registration.
            </p>

            <p>
              ✓ Paid plans continue into the existing secure Stripe checkout flow.
            </p>

            <p>
              ✓ Existing subscribers sign in and manage their current membership instead of creating a duplicate subscription.
            </p>
          </div>
        </section>

        <section className="p-6 sm:p-8 lg:p-12">
          <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--primary)]">
            Create account
          </p>

          <h2 className="mt-2 text-3xl font-black tracking-tight text-[var(--text-primary)]">
            Start CASE University
          </h2>

          <p className="mt-3 text-sm leading-6 text-[var(--text-secondary)]">
            Enter your details below. If you selected Plus or Pro on the pricing page, your plan choice will continue after account confirmation.
          </p>

          <div className="mt-8">
            <RegisterForm
              planKey={
                planKey
              }
              sourceProduct={
                sourceProduct
              }
            />
          </div>
        </section>
      </div>
    </main>
  );
}
